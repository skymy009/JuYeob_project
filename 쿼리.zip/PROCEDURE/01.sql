delimiter //

CREATE PROCEDURE add_guest(
IN a INT(11), b VARCHAR(100))

BEGIN

	INSERT INTO guests(guest_id, name) VALUES(a,b);
	
END;

//

delimiter ;