CALL add_guest(5, 'Brian');
