DROP TABLE IF EXISTS `vips`;

 SET character_set_client = utf8mb4 ;
CREATE TABLE `vips` (
  `vip_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`vip_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

