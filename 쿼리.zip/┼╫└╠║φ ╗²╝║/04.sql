DROP TABLE IF EXISTS `country_stats`;

 SET character_set_client = utf8mb4 ;
CREATE TABLE `country_stats` (
  `country_id` int(11) NOT NULL,
  `year` int(11) NOT NULL,
  `population` int(11) DEFAULT NULL,
  `gdp` decimal(15,0) DEFAULT NULL,
  PRIMARY KEY (`country_id`,`year`),
  CONSTRAINT `country_stats_ibfk_1` FOREIGN KEY (`country_id`) 
  REFERENCES `countries` (`country_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
