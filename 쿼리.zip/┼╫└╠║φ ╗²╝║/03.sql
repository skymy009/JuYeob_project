DROP TABLE IF EXISTS `country_languages`;

 SET character_set_client = utf8mb4 ;
CREATE TABLE `country_languages` (
  `country_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `official` tinyint(1) NOT NULL,
  PRIMARY KEY (`country_id`,`language_id`),
  KEY `language_id` (`language_id`),
  CONSTRAINT `country_languages_ibfk_1` FOREIGN KEY (`country_id`) 
  REFERENCES `countries` (`country_id`),
  CONSTRAINT `country_languages_ibfk_2` FOREIGN KEY (`language_id`) 
  REFERENCES `languages` (`language_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
