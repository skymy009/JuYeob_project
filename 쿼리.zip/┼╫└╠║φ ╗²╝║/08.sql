DROP TABLE IF EXISTS `regions`;

 SET character_set_client = utf8mb4 ;
CREATE TABLE `regions` (
  `region_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `continent_id` int(11) NOT NULL,
  PRIMARY KEY (`region_id`),
  KEY `continent_id` (`continent_id`),
  CONSTRAINT `regions_ibfk_1` FOREIGN KEY (`continent_id`) 
  REFERENCES `continents` (`continent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;

