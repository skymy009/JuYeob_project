delimiter //

CREATE TRIGGER guest_delete
BEFORE DELETE ON guests FOR EACH ROW
BEGIN
	INSERT INTO db_log(log_text, user_account, ts)
	VALUES('guest delete attempt', USER(), NOW());
END;

//
delimiter ;
