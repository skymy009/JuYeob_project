INSERT INTO `vips` VALUES (1,'Jane'),(2,'Charles')
,(3,'John'),(4,'Wolverine'),(5,'Rogue');