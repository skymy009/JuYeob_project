INSERT INTO `continents` VALUES 
(1,'North America'),(2,'Asia'),(3,'Africa'),(4,'Europe'),
(5,'South America'),(6,'Oceania'),(7,'Antarctica');