INSERT INTO `guests` VALUES (1,'John'),(2,'Jane')
,(3,'Jean'),(4,'Storm'),(5,'Beast');