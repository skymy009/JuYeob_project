SELECT regions.name AS regions_name, continents.name AS cotinent_name 
FROM continents join regions 
ON continents.continent_id = regions.continent_id;